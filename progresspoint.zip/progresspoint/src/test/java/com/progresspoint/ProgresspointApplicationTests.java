package com.progresspoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgresspointApplicationTests {

	@Test
	void contextLoads() {
	}

}
